<?php
/**
 * Lexicon Entries for ImageOptimOnUpload
 *
 * @package ImageOptimOnUpload
 * @subpackage lexicon
 */
$_lang['error.checkfile'] = 'Fehler: Bildgröße ist über 10.000 px oder > 50 MB';