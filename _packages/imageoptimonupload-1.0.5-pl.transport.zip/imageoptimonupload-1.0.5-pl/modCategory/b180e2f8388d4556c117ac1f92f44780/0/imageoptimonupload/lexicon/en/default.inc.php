<?php
/**
 * Setting Lexicon Entries for ImageOptimOnUpload
 *
 * @package ImageOptimOnUpload
 * @subpackage lexicon
 */
$_lang['error.checkfile'] = 'Error: Image size is over 10.000 px or > 50 MB';
